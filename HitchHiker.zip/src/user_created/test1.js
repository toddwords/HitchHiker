console.log('script loaded')

function hailSatan(){
	$('h1,h2,h3,h4,h5,h6,p,a,li').text("HAIL SATAN")
}

function addH1(txt){
	$('body').prepend("<h1>"+txt+"</h1>")
}
