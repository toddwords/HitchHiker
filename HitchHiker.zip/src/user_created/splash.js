function addSplash() {
    $("body").append(`<img 
        src='https://www.tate.org.uk/art/images/work/T/T03/T03254_9.jpg'
        style='position: fixed; top: 150px; left: 750px; width: 500px; height: 500px;'
    ></img>`)
}